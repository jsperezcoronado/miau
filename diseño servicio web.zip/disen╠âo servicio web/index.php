<?php
echo json_encode(["message" => "Bienvenido al servicio de autenticacion"]);
?>